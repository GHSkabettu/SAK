function generatePreview() {
  document.getElementById('preview-topic').innerText = document.getElementById('topic').value;
  document.getElementById('preview-subtopic').innerText = document.getElementById('subtopic').value;
  document.getElementById('preview-description').innerText = document.getElementById('description').value;

  const imageContainer = document.getElementById('image-container');
  imageContainer.innerHTML = '';

  const files = document.getElementById('imageInput').files;
  Array.from(files).forEach(file => {
    const reader = new FileReader();
    reader.onload = function (e) {
      const img = document.createElement('img');
      img.src = e.target.result;
      img.style.width = "300px"; // You can allow user resizing later
      imageContainer.appendChild(img);
    };
    reader.readAsDataURL(file);
  });
}

async function downloadPDF() {
  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF('p', 'pt', 'a4');

  const report = document.getElementById('report-preview');
  const canvas = await html2canvas(report, { scale: 2 });

  const imgData = canvas.toDataURL('image/png');
  const imgProps = pdf.getImageProperties(imgData);
  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

  pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
  pdf.save("Report.pdf");
}